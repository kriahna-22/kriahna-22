apicup subsys install mgmt upgrade_management_lts_<version>.tgz appliance-control-plane-1.19.x.tgz appliance-control-plane-1.18.x.tgz appliance-control-plane-1.17.x.tgz
apicup subsys install port upgrade_portal_lts_<version>.tgz appliance-control-plane-1.19.x.tgz appliance-control-plane-1.18.x.tgz appliance-control-plane-1.17.x.tgz
apicup subsys install analyt upgrade_analytics_lts_<version>.tgz appliance-control-plane-1.19.x.tgz appliance-control-plane-1.18.x.tgz appliance-control-plane-1.17.x.tgz


apicops task-queue:fix-stuck-tasks
apicops task-queue:list-stuck-tasks