

/home/v786memo/APIConnect_PRJ/apicup subsys health-check mgmt -v
/home/v786memo/APIConnect_PRJ/apicup subsys health-check port -v
/home/v786memo/APIConnect_PRJ/apicup subsys health-check analyt -v



/home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/apicup-linux_lts_v2018.4.1.17-ifix2.0 subsys install mgmt /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/upgrade_management_lts_v2018.4.1.17-ifix2.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.19.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.18.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.17.1.tgz
/home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/apicup-linux_lts_v2018.4.1.17-ifix2.0 subsys install port /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/upgrade_portal_lts_v2018.4.1.17-ifix2.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.19.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.18.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.17.1.tgz
/home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/apicup-linux_lts_v2018.4.1.17-ifix2.0 subsys install analyt /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/upgrade_analytics_lts_v2018.4.1.17-ifix2.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.19.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.18.0.tgz /home/v786memo/APIConnect_PRJ/4.1.17ifix2.0/appliance-control-plane-1.17.1.tgz


dpkg -l | grep esm



